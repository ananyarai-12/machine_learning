import pandas as pd
import numpy as np
import math
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# Load the datasets
df1 = pd.read_csv("iris_test.csv")
df2 = pd.read_csv("iris_train.csv")
df1=df1.drop("Unnamed: 0",axis=1)
df2=df2.drop("Unnamed: 0",axis=1)
X1 = df1.drop("Species", axis=1).values
X2 = df2.drop("Species", axis=1).values

# Q1 part a
def PCA(X):
    mean_subtracted_X = X - np.mean(X, axis=0)
    mean_subtracted_X_transpose= np.transpose(mean_subtracted_X)
    correlation_matrix= np.dot(mean_subtracted_X_transpose,mean_subtracted_X)
    evalue, evector = np.linalg.eig(correlation_matrix)
    es = np.argsort(evalue)
    evs = evector[:, es]
    Q = evs[:, -1]
    reduced_X = np.dot(mean_subtracted_X, Q)
    return reduced_X  # Return the reduced data instead of printing

print("PCA1 of test data:")
reduced_X1 = PCA(X1)
print(reduced_X1)

print("PCA1 of training data")
reduced_X2 = PCA(X2)
print(reduced_X2)

# Q1 part b
def gaussian(x, u, sd):
    a = math.exp(-0.5 * ((x - u) / sd) ** 2)
    b = math.sqrt(2 * math.pi) * sd
    prob = a / b
    return prob

l1 = list(df1['Species'])
l2 = list(df2['Species'])

l3 = []
for Ci in ['Iris-setosa','Iris-virginica','Iris-versicolor' ]:
    t = l2.count(Ci)
    P_Ci = t / len(l2)
    c = []
    for index, spec in enumerate(l2):
        if spec == Ci:
            j = reduced_X2  # Use reduced data for classification
            c.append(j[index])
    u = sum(c) / len(c)
    sd = np.std(c)
    x = [P_Ci, u, sd, Ci]
    l3.append(x)

l4=[]
for x in reduced_X1:
    y1= gaussian(x,l3[0][1],l3[0][2])*l3[0][0]
    y2= gaussian(x,l3[1][1],l3[1][2])*l3[1][0]
    y3= gaussian(x,l3[2][1],l3[2][2])*l3[2][0]
    
    if y1 == max(y1,y2,y3):
        s= l3[0][3]
    elif y2 == max(y1,y2,y3):
        s= l3[1][3]
    elif y3== max(y1,y2,y3):
        s= l3[2][3]
    l4.append([x,s])

df3 = pd.DataFrame(l4, columns=['X','Species'])
print(df3)

#Q1 partc
actual= df1['Species']
predicted= df3['Species']
con_matrix=confusion_matrix(actual,predicted)
print("Confusion Matrix: ")
print(con_matrix)

ConfusionMatrixDisplay(con_matrix,display_labels=['C1','C2','C3']).plot()
plt.show()

accuracy1= (con_matrix[0][0]+con_matrix[1][1]+con_matrix[2][2])/np.sum(con_matrix)
print("The accuracy of this model is",accuracy1*100,"%")