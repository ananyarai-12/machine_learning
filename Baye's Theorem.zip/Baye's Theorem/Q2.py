import pandas as pd
import numpy as np
from scipy.stats import multivariate_normal
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay
import matplotlib.pyplot as plt

def mean_(x):
    return sum(x)/len(x)

def s_d(data):
    mean = mean_(data)
    squared_diff = [(x - mean) ** 2 for x in data]
    return (sum(squared_diff) / len(data))** 0.5

# Load the datasets
df1 = pd.read_csv("iris_test.csv")
df2 = pd.read_csv("iris_train.csv")
df1 = df1.drop("Unnamed: 0", axis=1)
df2 = df2.drop("Unnamed: 0", axis=1)
X1 = df1.drop("Species", axis=1)
X2 = df2.drop("Species", axis=1)

# Define the classes and class labels
classes = ['Iris-versicolor', 'Iris-virginica', 'Iris-setosa']
class_labels = [0, 1, 2]

# Function to calculate the Gaussian probability
def gaussian(x, mean, covariance):
    mvn = multivariate_normal(mean=mean, cov=covariance)
    return mvn.pdf(x)

# List to store class parameters (P(Ci), mean, covariance, class label)
class_parameters = []

# Estimate parameters for each class
for i, class_name in enumerate(classes):
    class_data = X2[df2['Species'] == class_name]
    mean = mean_(np.array(class_data))
    covariance = class_data.cov()
    p_class = len(class_data) / len(df2)
    class_parameters.append((p_class, mean, covariance, class_labels[i]))

# List to store the predicted results
predicted_results = []

# Classify the test samples
for index, row in X1.iterrows():
    sample = row.values
    likelihoods = []

    for p_class, mean, covariance, class_label in class_parameters:
        likelihood = gaussian(sample, mean, covariance)
        likelihoods.append(p_class * likelihood)

    predicted_class = class_parameters[np.argmax(likelihoods)][3]
    predicted_results.append(predicted_class)

# Add the predicted class labels to the test dataframe
df1['Predicted_Species'] = [classes[label] for label in predicted_results]

# Print the test dataframe with predicted classes
#print(df1)

actual= df1['Species']
predicted= df1['Predicted_Species']
con_matrix=confusion_matrix(actual,predicted)
print("Confusion Matrix: ")
print(con_matrix)

ConfusionMatrixDisplay(con_matrix,display_labels=['C1','C2','C3']).plot()
plt.show()

accuracy2= (con_matrix[0][0]+con_matrix[1][1]+con_matrix[2][2])/np.sum(con_matrix)
print("The accuracy of this model is",accuracy2*100,"%")