import x11
import y1

accuracy_1= x11.accuracy1
accuracy_2= y1.accuracy2

print("The difference between the accuracies of the two models is", accuracy_1-accuracy_2)