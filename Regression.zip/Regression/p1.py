import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

def regression(x,y,X):
    a= np.dot(np.transpose(X),X)
    b= np.transpose(X)
    
    c= np.linalg.inv(a)
    d= np.dot(c,b)
    w_cap= np.dot(d,y)
    e=np.dot(np.transpose(w_cap),x)
    return e

def pearson(x,y):
    ux= sum(x)/len(x)
    uy= sum(y)/len(y)
    sum1,sum2,sum3=0,0,0
    for i in range(len(x)):
        sum1+= (x[i]-ux)*(y[i]-uy)
        sum2+= (x[i]-ux)**2
        sum3+= (y[i]-uy)**2
    pc= sum1/((sum2*sum3)**0.5)
    return pc

def rmse(x,y):
    b=0
    for i in range (len(x)):
        a= x[i]-y[i]
        b+=a**2
    c= (b/len(x))**0.5
    return c[0]
        
#q1 
df= pd.read_csv("Assignment-4/abalone.csv")
from sklearn.model_selection import train_test_split
train_data, test_data = train_test_split(df, test_size=0.3, random_state=42)

train_data.to_csv("abalone_train.csv", index=False)
test_data.to_csv("abalone_test.csv", index=False)

#q2 
df1 = pd.read_csv("abalone_train.csv")
df2 = pd.read_csv("abalone_test.csv")
x1= df1.drop("Rings",axis=1)
x2= df2.drop("Rings",axis=1)
l1=[]
for col in x1.columns:
    l1.append(pearson(np.array(df1[col]),np.array(df1["Rings"])))

z= l1.index(max(l1))

l2= []
for val in np.array(df1[x1.columns[z]]):
    l2.append([1,val])

l3= []
for val2 in df1["Rings"].values :
    l3.append([val2])
l4= np.array(df2[x2.columns[z]])
predicted_values_q2=[]

for i in range(len(l4)):
    x= [1,l4[i]]
    predicted_values_q2.append(regression(x,l3,l2))

predicted_values_q2_train=[]
l6= np.array(df1[x1.columns[z]])
for i in range(len(l6)):
    x= [1,l6[i]]
    predicted_values_q2_train.append(regression(x,l3,l2))


l5=[]
for i in range(len(predicted_values_q2)):
    l5.append(predicted_values_q2[i][0])


#part1
plt.plot(np.array(df2[x2.columns[z]]),l5,color='black')
plt.scatter(np.array(df1[x1.columns[z]]),np.array(df1["Rings"]),color='pink',marker='*')
plt.xlabel("x")
plt.ylabel("mx+c")
plt.show()

#part2
predicted_values_q2_train=[]
l6= np.array(df1[x1.columns[z]])
for i in range(len(l6)):
    x= [1,l6[i]]
    predicted_values_q2_train.append(regression(x,l3,l2))

print("RMSE error for training data is:", rmse(predicted_values_q2_train,np.array(df1["Rings"])))

#part3
  
print("RMSE error for testing data is:", rmse(predicted_values_q2,np.array(df2["Rings"])))

#part4
plt.scatter(np.array(df2["Rings"]),l5,color='purple',marker='x')
plt.xlabel("ACTUAL")
plt.ylabel("PREDICTED")
plt.show()


#q3

#part1

lst1,lst2,lst3,lst4=[],[],[],[]
for val in np.array(df1[x1.columns[z]]):
    lst1.append([1,val,val**2])
    lst2.append([1,val,val**2,val**3])
    lst3.append([1,val,val**2,val**3,val**4])
    lst4.append([1,val,val**2,val**3,val**4,val**5])

l7= np.array(df2[x2.columns[z]])
predicted_values_q3_1,predicted_values_q3_2,predicted_values_q3_3,predicted_values_q3_4=[],[],[],[]

for i in range(len(l7)):
    x= [1,l7[i],l7[i]**2]
    x_1= [1,l7[i],l7[i]**2,l7[i]**3]
    x_2= [1,l7[i],l7[i]**2,l7[i]**3,l7[i]**4]
    x3= [1,l7[i],l7[i]**2,l7[i]**3,l7[i]**4,l7[i]**5]
    predicted_values_q3_1.append(regression(x,l3,lst1))
    predicted_values_q3_2.append(regression(x_1,l3,lst2))
    predicted_values_q3_3.append(regression(x_2,l3,lst3))
    predicted_values_q3_4.append(regression(x3,l3,lst4))

bar1= [rmse(predicted_values_q3_1,np.array(df2["Rings"])),rmse(predicted_values_q3_2,np.array(df2["Rings"])),rmse(predicted_values_q3_3,np.array(df2["Rings"])),rmse(predicted_values_q3_4,np.array(df2["Rings"]))]
x_axis=['degree 2','degree 3','degree 4','degree 5']

print("The RMSE values of testing data are:",bar1)
plt.bar(x_axis,bar1,color='maroon',width=0.4)
plt.show()

#part2

predicted_values_q3_train_1,predicted_values_q3_train_2,predicted_values_q3_train_3,predicted_values_q3_train_4=[],[],[],[]
l8= np.array(df1[x1.columns[z]])
for i in range(len(l8)):
    x_= [1,l8[i],l8[i]**2]
    x1_= [1,l8[i],l8[i]**2,l8[i]**3]
    x2_= [1,l8[i],l8[i]**2,l8[i]**3,l8[i]**4]
    x3= [1,l8[i],l8[i]**2,l8[i]**3,l8[i]**4,l8[i]**5]
    
    predicted_values_q3_train_1.append(regression(x_,l3,lst1))
    predicted_values_q3_train_2.append(regression(x1_,l3,lst2))
    predicted_values_q3_train_3.append(regression(x2_,l3,lst3))
    predicted_values_q3_train_4.append(regression(x3,l3,lst4))

bar2= [rmse(predicted_values_q3_train_1,np.array(df1["Rings"])),rmse(predicted_values_q3_train_2,np.array(df1["Rings"])),rmse(predicted_values_q3_train_3,np.array(df1["Rings"])),rmse(predicted_values_q3_train_4,np.array(df1["Rings"]))]

print("The RMSE values of training data are:",bar2)
plt.bar(x_axis,bar2,color='maroon',width=0.4)
plt.show()

#part3
pred_vals=[predicted_values_q3_train_1,predicted_values_q3_train_2,predicted_values_q3_train_3,predicted_values_q3_train_4]
h= bar2.index(min(bar2))
x=np.arange(0,1,0.01)
lst5=[]
lst6=[]
for i in x:
    j= [1,i,i**2,i**3,i**4,i**5]
    lst5.append(j)
for b in lst5:
    lst6.append(regression(b,l3,lst4))
print(lst6)
plt.plot(x,lst6,color='red')
plt.scatter(np.array(df1[x1.columns[z]]),np.array(df1["Rings"]),color='cyan',marker='*')
plt.show()
'''optimal_lst= pred_vals[h]

l9=[]
for i in range(len(optimal_lst)):
    l9.append(optimal_lst[i][0])

plt.plot(np.array(df1[x1.columns[z]]),l9,color='red')
plt.scatter(np.array(df1[x1.columns[z]]),np.array(df1["Rings"]),color='cyan',marker='*')
plt.show()'''