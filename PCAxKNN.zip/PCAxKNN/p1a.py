import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
import sklearn.model_selection
from collections import Counter 
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

df= pd.read_csv("Iris.csv")

# Q1 part a
X = df.drop("Species", axis=1).values
Y= np.array(df['Species'])

#Q1 part b
X2=[]
for i in ['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']:
    x1= np.array(df[i])
    median=np.median(x1)
    q3= np.percentile(x1,75)
    q1= np.percentile(x1,25)
    iqr= q3-q1
    upper= q3+1.5*iqr
    lower= q1-1.5*iqr
    for j in range(len(x1)):
        if x1[j]>upper or x1[j]<lower:
            x1[j]=median
    X2.append(x1)
            
X1= np.transpose(X2)
#Q1 part c

mean_subtracted_X= X1- np.mean(X1, axis=0)

mean_subtracted_X_transpose=np.transpose(mean_subtracted_X)

correlation_matrix= mean_subtracted_X_transpose.dot(mean_subtracted_X)

evalue,evector = np.linalg.eig(correlation_matrix)

Q=evector[:,:2]
print(Q)
reduced= X1.dot(Q)
reduced_X=pd.DataFrame(reduced,columns=['PCA1','PCA2'])


#Q1 part d


plt.figure(figsize=(8, 4))
plt.scatter(reduced_X["PCA1"],reduced_X["PCA2"], c='#ADD8E6', marker='o')
plt.xlabel('First Principal Component')
plt.ylabel('Second Principal Component')
plt.title('PCA: First vs Second Principal Component')
plt.grid()

mx= np.mean(reduced_X['PCA1'])
my= np.mean(reduced_X['PCA2'])
plt.quiver(mx, my, evector[0,0], evector[0,1], angles= 'xy', scale_units='xy', scale=1,color='#03A89E', label='Eigenvector1')
plt.quiver(mx, my, evector[1,0], evector[1,1], angles= 'xy', scale_units='xy', scale=1, color='#FF6A6A',label='Eigenvector1')
plt.legend()
plt.show()

#Q1 part e

reconstruct= np.dot(reduced_X,Q.T)
reconstructed_X=pd.DataFrame(reconstruct,columns=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm'])
print(reconstructed_X)

#Q1 part f
from sklearn.metrics import mean_squared_error 

o= X1.transpose()
p= reconstruct.transpose()
for j in range(4):
    sum1=0
    for k in range(150):
        s= (o[j][k]-p[j][k])**2
        sum1+=s
    rmse= (sum1/150)**0.5
    print("RMSE",j+1,rmse)

#Q2 part a
from sklearn.model_selection import train_test_split

reduced_X_train, reduced_X_test, Y_train, Y_test = train_test_split(reduced_X, Y, random_state=104, test_size=0.20, shuffle=True)

actual_predicted=[]
pred=[]
for u in range(len(reduced_X_test)):
    distances=[]
    for v in range(len(reduced_X_train)):
        d= np.sqrt(np.sum((reduced_X_test.iloc[u]-reduced_X_train.iloc[v])**2))
        distances.append(d)
    
    dist= np.argsort(distances)
    dis= sorted(distances)
    yt = Y_train[dist]

    top5= dis[:5]
    top5species= yt[:5]
    freq= Counter(top5species)
    predicted= freq.most_common(1)[0][0]
    pred.append(predicted)
    e=[Y_test[u],predicted]
    actual_predicted.append(e)


#Q2 partb
actual= Y_test
predicted= pred
con_matrix=confusion_matrix(actual,predicted)
print("Confusion Matrix: ")
print(con_matrix)

ConfusionMatrixDisplay(con_matrix,display_labels=['C1','C2','C3']).plot()
plt.show()