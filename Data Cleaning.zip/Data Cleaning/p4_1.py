import pandas as pd

df= pd.read_csv("outliers.csv")
lst= ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']
for attribute in lst:
    min_value = df[attribute].min()
    max_value = df[attribute].max()
    print('attribute=', attribute)
    print('Min before normalization:', df[attribute].min())
    print('Max before normalization:', df[attribute].max())
    df[attribute] = ((df[attribute] - min_value) / (max_value - min_value) )* (12 - 5) + 5

for attribute in lst:
    print('Attribute:', attribute)
    print('Min after normalization:', df[attribute].min())
    print('Max after normalization:', df[attribute].max())