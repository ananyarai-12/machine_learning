import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df= pd.read_csv("landslide_data_filled_1.csv")
lst=['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']

new_df= pd.DataFrame()

for column in lst:
    l1= df[column]
    l2= np.array(l1)
    t=0
    m= len(l2)-1
    if m%2==0:
        median1 = (l2[m//2+1]+l2[m//2])/2
    else:
        median1= l2[m+1//2]
    
    q1 = np.quantile(l2, 0.25)
    q3 = np.quantile(l2, 0.75)
    iqr = q3-q1
    upper_bound = q3+(1.5*iqr)
    lower_bound = q1-(1.5*iqr)
    #print(iqr, upper_bound, lower_bound)
    l3=[]
    for j in l2:
        if j>= lower_bound and j<= upper_bound:
            l3.append(j)
        else:
            l3.append(median1)
    l3= np.array(l3)
    new_df[column]= l3.tolist()

    
    plt.boxplot(l3)
    plt.xlabel(column)
    plt.show()

new_df.to_csv("outliers.csv")