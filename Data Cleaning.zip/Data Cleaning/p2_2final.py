import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def lin_int(Yprev, Ynext, Xprev, Xnext, Xdefine):
    return Yprev + (((Xdefine - Xprev) / (Xnext - Xprev)) * (Ynext - Yprev))

df = pd.read_csv("landslide_data_miss.csv")
df["dates"]=pd.to_datetime(df["dates"],dayfirst=True)
df.dropna(subset=['stationid'],inplace=True)
df= df.drop(df[df.isna().sum(axis=1)>2].index)
df.reset_index(inplace=True,drop=True)

for j in range(df.shape[1]):
    for i in range(df.shape[0]):
        y = df.iloc[i, j]
        if pd.isnull(y):
            Xdefine = df.iloc[i, 0]
            for k in range(i-1,-1,-1):
                if pd.isnull(df.iloc[k,j]):
                    continue
                else:
                    Yprev = df.iloc[k,j]
                    Xprev = df.iloc[k,0]
                    break
            
            for l in range(i+1,df.shape[0]):
                if pd.isnull(df.iloc[l,j]):
                    continue
                else:
                    Ynext= df.iloc[l,j]
                    Xnext= df.iloc[l,0]
                    break
            df.iloc[i, j] = lin_int(Yprev, Ynext, Xprev, Xnext, Xdefine)

print(df)


#part a
df.to_csv("landslide_data_filled_1.csv")
df2= pd.read_csv("landslide_data_filled_1.csv")

lst1 = ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']

df3= pd.read_csv("landslide_data_original.csv")

for column in lst1:
    t1=df2[column]
    t2= np.array(t1)
    t3=df3[column]
    t4= np.array(t3)
    mean = (t2.sum())/len(t2)
    mean2= (t4.sum()/len(t4))
    print("the comparitive mean for ", column)
    print("of mean=", mean2 ,' ' , "interpolated mean=", mean)
    print()
    t5=sorted(t2)
    t6= sorted(t4)
    m= len(t5)-1
    n= len(t6)-1
    if m%2==0:
        median1 = (t5[m//2+1]+t5[m//2])/2
    else:
        median1= t5[m+1//2]
    if n%2==0:
        median2 = (t6[n//2+1]+t6[n//2])/2
    else:
        median2 = t6[n+1//2]
    print("the comparitive median for ", column)
    print("og median=", median2 ,' ' , "interpolated median=", median1)
    print()    
    l2=0
    l3=0
    for i in t2:
        j = (i-mean)**2
        l2+=j
    s= (l2/len(t2))**0.5
    for i in t4:
        j = (i-mean)**2
        l3+=j
    s1= (l3/len(t4))**0.5
    print("the comparitive std for ", column)
    print("og std =", s1 ,' ' , "interpolated std=", s)
    print()
    print()
    print()


#part b
rmse=[]
for column in lst1:
    sum1=0
    t1=df2[column]
    t2= np.array(t1)
    t3=df3[column]
    t4= np.array(t3)
    for i in range(len(t2)):
        x= (t4[i]-t2[i])**2
        sum1+=x
    r_value= (sum1/len(t2))**0.5
    rmse.append(r_value)

plt.plot(lst1,rmse)
#plt.grid(color='blue',linestyle='--',linewidth=0.5)
plt.xlabel("Attribute")
plt.ylabel("RMSEs")
plt.title("RMSEs vs Attributes")
plt.show()