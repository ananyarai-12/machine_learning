import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df= pd.read_csv("landslide_data_filled_1.csv")
lst=['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']

for column in lst:
    l1= df[column]
    l2= np.array(l1)
    plt.boxplot(l2)
    plt.xlabel(column)
    plt.title("boxplot")
    plt.show()