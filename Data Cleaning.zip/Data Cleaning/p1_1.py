import pandas as pd
import numpy as np

df = pd.read_csv("landslide_data_original.csv")
t1=df["temperature"]
t2= np.array(t1)
#print(t2)
mean = (t2.sum())/len(t2)
print("mean temp is:", np.round(mean,2))
for i in t2:
    l1=0
    for j in t2:
        if i<=j:
            l1+=1
    if l1== len(t2):
        print("the minimum temp is:",np.round(i,2))
        break
for i in t2:
    l1=0
    for j in t2:
        if i>=j:
            l1+=1
    if l1== len(t2):
        print("the maximum temp is:",np.round(i,2))
        break
l2=0
for i in t2:
    j = (i-mean)**2
    l2+=j
s= (l2/len(t2))**0.5
print("standard deviation of the temperature is:", np.round(s,2))