import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df = pd.read_csv("landslide_data_original.csv")
print(df)
data = df[df['stationid']=='t12']['humidity']
print(data)

plt.hist(data, bins=5)
plt.xlabel('humidity')
plt.ylabel('stationid')
plt.title('histogram')
plt.show()