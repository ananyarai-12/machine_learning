import pandas as pd
import numpy as np

df= pd.read_csv("outliers.csv")
lst= ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']
for attribute in lst:
    mean= np.mean(np.array(df[attribute]))
    std = np.std(np.array(df[attribute]))
    print('Attribute:', attribute)
    print('mean before normalization:', mean)
    print('standard deviation beforenormalization:', std)
    df[attribute] = (df[attribute] - mean) / std

for attribute in lst:
    print('Attribute:', attribute)
    print('mean after normalization:', np.mean(np.array(df[attribute])))
    print('standard deviation after normalization:', np.std(np.array(df[attribute])))