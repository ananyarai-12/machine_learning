import pandas as pd
import numpy as np

# Read the CSV file
df = pd.read_csv("landslide_data_original.csv")

# List of columns to calculate correlations for
columns_to_correlate = ["temperature", "humidity", "pressure", "rain", "lightavg", "lightmax", "moisture"]

def correlation(a, b, c, d):
    sum1 = 0
    sum2 = 0
    sum3 = 0
    for i in range(len(c)):
        u = (c[i] - a) ** 2
        v = (d[i] - b) ** 2
        w = (c[i] - a) * (d[i] - b)
        sum1 += u
        sum2 += v
        sum3 += w
    r = sum3 / ((sum2 * sum1) ** 0.5)
    return r

correlation_matrix = []

for col1 in columns_to_correlate:
    col1_values = df[col1].astype(float)
    x1 = col1_values.mean()
    row = []
    for col2 in columns_to_correlate:
        col2_values = df[col2].astype(float)
        x2 = col2_values.mean()
        corr = correlation(x1, x2, col1_values, col2_values)
        row.append(corr)
    correlation_matrix.append(row)

# Add column names to the matrix
#correlation_matrix.insert(0, columns_to_correlate)
correlation_matrix[0].insert(0,'temperature')
correlation_matrix[1].insert(0,'humidity')
correlation_matrix[2].insert(0,'pressure')
correlation_matrix[3].insert(0,'rain')
correlation_matrix[4].insert(0,'lightavg')
correlation_matrix[5].insert(0,'lightmax')
correlation_matrix[6].insert(0,'moisture')


# Create a DataFrame from the correlation matrix
df1 = pd.DataFrame(correlation_matrix, columns=['']+columns_to_correlate)

print(df1)

print()
print()
print()

row_names= np.array(df1[''])
lightavg_values=np.array(df1['lightavg'])
for i in range(len(lightavg_values)):
    if lightavg_values[i]>=0.6:
        print("redundant attribute with respect to lightavg is ", row_names[i])
        print()
